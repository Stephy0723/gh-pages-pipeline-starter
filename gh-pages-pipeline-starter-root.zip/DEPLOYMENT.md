# Instrucciones de Despliegue (GitHub Pages)

1. Habilita Pages: Settings → Pages → Source: GitHub Actions.
2. Revisa `.github/workflows/pages.yml` (rama `main`).
3. Haz un commit a `main`. El workflow construye y despliega.
4. URL final: `https://<usuario>.github.io/<repo>/`
   - El `base` en `vite.config.js` se ajusta automáticamente con `GITHUB_REPOSITORY`.
