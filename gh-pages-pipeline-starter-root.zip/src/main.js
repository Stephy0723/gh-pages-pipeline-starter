import { greet } from './utils.js';

document.querySelector('#msg').textContent = greet('pipeline');
