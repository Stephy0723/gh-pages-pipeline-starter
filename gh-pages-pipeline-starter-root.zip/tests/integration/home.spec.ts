import { test, expect } from '@playwright/test';

test('renderiza el título y el saludo', async ({ page }) => {
  const base = process.env.PLAYWRIGHT_BASE_URL || 'http://localhost:4173/';
  await page.goto(base);
  await expect(page.locator('#title')).toHaveText('Hola Pipeline 👋');
  await expect(page.locator('#msg')).toHaveText('Hola, pipeline!');
});
