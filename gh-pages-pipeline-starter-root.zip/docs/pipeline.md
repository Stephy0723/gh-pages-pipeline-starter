# Documentación del Pipeline

```mermaid
flowchart LR
A[Push/PR en main] --> B[Install deps]
B --> C[Unit tests + coverage]
C --> D[Build]
D --> E[Preview server]
E --> F[Playwright e2e]
F -->|OK| G[Upload artifact]
G --> H[Deploy Pages]
```

## Etapas
1. **Install**: `npm ci` con caché.
2. **Unit tests**: Vitest + cobertura V8.
3. **Build**: Vite genera `/dist`.
4. **Preview**: `vite preview` en puerto 4173.
5. **E2E**: Playwright contra `PLAYWRIGHT_BASE_URL`.
6. **Artifact**: `dist` para Pages.
7. **Deploy**: `actions/deploy-pages`.

## Convenciones
- Ramas: `main` estable, `feat/*`, `fix/*`.
- PRs requieren checks verdes antes de merge.
