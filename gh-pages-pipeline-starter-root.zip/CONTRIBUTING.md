# Guía de Contribución

## Flujo
1. Crea rama desde `main`: `feat/xyz` o `fix/bug`.
2. `npm ci` y desarrolla con `npm run dev`.
3. Asegura `npm run test:unit` y `npm run test:integration` en local.
4. Abre PR con descripción clara.

## Estilo
- JS con ESM.
- Commits tipo Conventional Commits (recomendado): `feat:`, `fix:`, etc.

## Pruebas
- Unitarias en `tests/unit/`.
- Integración en `tests/integration/`.
- Cobertura mínima sugerida: 80% líneas/funciones.
