export function greet(name = 'mundo') {
  return `Hola, ${name}!`;
}
