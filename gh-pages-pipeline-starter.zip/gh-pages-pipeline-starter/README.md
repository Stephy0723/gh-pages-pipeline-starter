# GH Pages Pipeline Starter

Proyecto base con:
- App web simple (Vite)
- Pruebas unitarias (Vitest) + cobertura
- Pruebas de integración (Playwright)
- CI/CD con GitHub Actions
- Despliegue automático a GitHub Pages

## Requisitos
- Node.js 20+
- npm 9+

## Uso local
```bash
npm ci
npm run dev          # desarrollo
npm run test:unit    # unit tests + coverage
npm run build        # build
npm run preview      # servidor para probar build
npm run test:integration  # e2e con Playwright (requiere preview)
```

## CI/CD
Cada push/PR a `main` ejecuta: unit tests → build → integration tests → deploy a GitHub Pages.

## Cobertura
- Generada con `@vitest/coverage-v8` en `./coverage` (lcov + texto).

## Enlaces
- **Página**: `https://<tu-usuario>.github.io/<tu-repo>/`
- **Acciones**: pestaña *Actions* del repo

## Estructura
Ver árbol de carpetas en este README.

## Licencia
MIT
