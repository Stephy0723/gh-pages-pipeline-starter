import { describe, it, expect } from 'vitest';
import { greet } from '../../src/utils.js';

describe('greet', () => {
  it('saluda por defecto', () => {
    expect(greet()).toBe('Hola, mundo!');
  });
  it('saluda por nombre', () => {
    expect(greet('Stephanie')).toBe('Hola, Stephanie!');
  });
});
