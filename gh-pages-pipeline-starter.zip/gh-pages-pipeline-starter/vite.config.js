// vite.config.js
import { defineConfig } from 'vite';

export default defineConfig({
  // Soporta despliegue en subruta de GitHub Pages: https://<user>.github.io/<repo>/
  base: process.env.GITHUB_REPOSITORY ? `/${process.env.GITHUB_REPOSITORY.split('/')[1]}/` : '/',
});
